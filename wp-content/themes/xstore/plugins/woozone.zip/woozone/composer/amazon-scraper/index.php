<?php die('silence is gold!');
/*
{
    "name": "woozone/amazon-scraper",
    "license": "MIT",
    "description": "Amazon Product Page Scraping Script",
    "keywords": ["amazon", "scraping", "scraper", "webscraping"],
    "type": "library",
    "authors": [],
    "require": {
        "php": "^5.5.9|>=7.0.8",
        "osushi/jsobj2php": "*",
        "symfony/dom-crawler": "^3.4",
        "symfony/css-selector": "~2.8|~3.0|~4.0",
        "ext-json": "*",
        "ext-iconv": "*"
    },
    "require-dev": {
        "phpunit/phpunit": "^8"
    },
    "autoload": {
        "psr-4": {
            "WooZone\\AmazonScraper\\": ["src/"]
        },
        "files": [],
        "exclude-from-classmap": []
    }
}
*/