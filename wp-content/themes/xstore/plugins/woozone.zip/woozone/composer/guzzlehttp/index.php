<?php die; ?>
library is moved in composer_prefixed and prefixed with php-scoper! ask developer for details!