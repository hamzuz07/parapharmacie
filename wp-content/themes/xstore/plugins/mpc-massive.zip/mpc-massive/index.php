<?php
// Silence! I kill you! ;)
